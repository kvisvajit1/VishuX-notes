document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const notesList = document.querySelector('.notes-list');
    const noteTitle = document.getElementById('note-title');
    const noteContent = document.getElementById('note-content');
    const newNoteBtn = document.getElementById('new-note-btn');
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    const favoriteBtn = document.getElementById('favorite-btn');
    const folderBtn = document.getElementById('folder-btn');
    const folders = document.querySelectorAll('.folder');
    
    // Toolbar buttons
    const boldBtn = document.getElementById('bold-btn');
    const italicBtn = document.getElementById('italic-btn');
    const headingBtn = document.getElementById('heading-btn');
    const listBtn = document.getElementById('list-btn');
    const numberedListBtn = document.getElementById('numbered-list-btn');
    const checklistBtn = document.getElementById('checklist-btn');
    
    // Notes data
    let notes = JSON.parse(localStorage.getItem('vishux-notes')) || [];
    let currentNoteId = null;
    let currentFolder = 'all';
    
    // Initialize the app
    function init() {
        renderFolders();
        renderNotesList();
        if (notes.length > 0) {
            openNote(notes[0].id);
        } else {
            createNewNote();
        }
        
        // Set up event listeners
        setupEventListeners();
    }
    
    // Set up event listeners
    function setupEventListeners() {
        // New note button
        newNoteBtn.addEventListener('click', createNewNote);
        
        // Sidebar toggle
        sidebarToggle.addEventListener('click', toggleSidebar);
        
        // Note title/content changes
        noteTitle.addEventListener('input', saveNote);
        noteContent.addEventListener('input', saveNote);
        
        // Toolbar buttons
        boldBtn.addEventListener('click', () => formatText('bold'));
        italicBtn.addEventListener('click', () => formatText('italic'));
        headingBtn.addEventListener('click', () => formatText('heading'));
        listBtn.addEventListener('click', () => formatText('unordered-list'));
        numberedListBtn.addEventListener('click', () => formatText('ordered-list'));
        checklistBtn.addEventListener('click', () => formatText('checklist'));
        favoriteBtn.addEventListener('click', toggleFavorite);
        folderBtn.addEventListener('click', changeFolder);
        
        // Folder selection
        folders.forEach(folder => {
            folder.addEventListener('click', () => {
                currentFolder = folder.dataset.folder;
                renderFolders();
                renderNotesList();
            });
        });
    }
    
    // Toggle sidebar collapse
    function toggleSidebar() {
        sidebar.classList.toggle('collapsed');
    }
    
    // Render folder list with counts
    function renderFolders() {
        folders.forEach(folder => {
            folder.classList.remove('active');
            
            // Update counts
            const folderType = folder.dataset.folder;
            const count = getNoteCount(folderType);
            folder.querySelector('.count').textContent = count;
            
            // Set active folder
            if (folderType === currentFolder) {
                folder.classList.add('active');
            }
        });
    }
    
    // Get note count for a folder
    function getNoteCount(folderType) {
        if (folderType === 'all') return notes.length;
        if (folderType === 'favorites') return notes.filter(n => n.favorite).length;
        return notes.filter(n => n.folder === folderType).length;
    }
    
    // Render notes list
    function renderNotesList() {
        notesList.innerHTML = '';
        
        let filteredNotes = [...notes];
        
        // Filter by folder
        if (currentFolder === 'favorites') {
            filteredNotes = filteredNotes.filter(n => n.favorite);
        } else if (currentFolder !== 'all') {
            filteredNotes = filteredNotes.filter(n => n.folder === currentFolder);
        }
        
        // Sort by updated time (newest first)
        filteredNotes.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
        
        filteredNotes.forEach(note => {
            const noteElement = document.createElement('div');
            noteElement.className = 'note-item';
            if (note.id === currentNoteId) {
                noteElement.classList.add('active');
            }
            if (note.favorite) {
                noteElement.classList.add('favorite');
            }
            
            const favoriteIcon = note.favorite ? '<i class="fas fa-star"></i>' : '';
            
            noteElement.innerHTML = `
                <div class="note-item-title">${favoriteIcon}${note.title || 'Untitled Note'}</div>
                <div class="note-item-preview">${getPreviewText(note.content)}</div>
                <div class="note-item-date">${formatDate(note.updatedAt)}</div>
            `;
            
            noteElement.addEventListener('click', () => openNote(note.id));
            notesList.appendChild(noteElement);
        });
    }
    
    // Get preview text for note list
    function getPreviewText(content) {
        if (!content) return 'No content';
        
        // Create a temporary div to parse HTML
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = content;
        
        // Get text content and remove extra whitespace
        let text = tempDiv.textContent || '';
        text = text.replace(/\s+/g, ' ').trim();
        
        // Return first 100 characters
        return text.substring(0, 100) + (text.length > 100 ? '...' : '');
    }
    
    // Format date for display
    function formatDate(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        
        // If today, show time only
        if (date.toDateString() === now.toDateString()) {
            return date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        }
        
        // If this year, show month and day
        if (date.getFullYear() === now.getFullYear()) {
            return date.toLocaleDateString([], {month: 'short', day: 'numeric'});
        }
        
        // Otherwise show full date
        return date.toLocaleDateString([], {year: 'numeric', month: 'short', day: 'numeric'});
    }
    
    // Create a new note
    function createNewNote() {
        const newNote = {
            id: Date.now().toString(),
            title: '',
            content: '',
            folder: 'personal',
            favorite: false,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        notes.unshift(newNote);
        saveToLocalStorage();
        openNote(newNote.id);
        renderFolders();
        renderNotesList();
        
        // Focus on title field
        setTimeout(() => {
            noteTitle.focus();
        }, 0);
    }
    
    // Open a note
    function openNote(noteId) {
        const note = notes.find(n => n.id === noteId);
        if (!note) return;
        
        currentNoteId = noteId;
        noteTitle.value = note.title;
        noteContent.innerHTML = note.content;
        
        // Update favorite button state
        if (note.favorite) {
            favoriteBtn.classList.add('favorited');
            favoriteBtn.innerHTML = '<i class="fas fa-star"></i>';
        } else {
            favoriteBtn.classList.remove('favorited');
            favoriteBtn.innerHTML = '<i class="far fa-star"></i>';
        }
        
        renderNotesList();
    }
    
    // Save the current note
    function saveNote() {
        if (!currentNoteId) return;
        
        const noteIndex = notes.findIndex(n => n.id === currentNoteId);
        if (noteIndex === -1) return;
        
        notes[noteIndex].title = noteTitle.value;
        notes[noteIndex].content = noteContent.innerHTML;
        notes[noteIndex].updatedAt = new Date().toISOString();
        
        saveToLocalStorage();
        renderFolders();
        renderNotesList();
    }
    
    // Toggle favorite status
    function toggleFavorite() {
        if (!currentNoteId) return;
        
        const noteIndex = notes.findIndex(n => n.id === currentNoteId);
        if (noteIndex === -1) return;
        
        notes[noteIndex].favorite = !notes[noteIndex].favorite;
        notes[noteIndex].updatedAt = new Date().toISOString();
        
        saveToLocalStorage();
        openNote(currentNoteId); // Refresh the view
        renderFolders();
        renderNotesList();
    }
    
    // Change folder for current note
    function changeFolder() {
        if (!currentNoteId) return;
        
        // Simple implementation - cycles through folders
        const noteIndex = notes.findIndex(n => n.id === currentNoteId);
        if (noteIndex === -1) return;
        
        const foldersOrder = ['personal', 'work', 'all'];
        const currentFolderIndex = foldersOrder.indexOf(notes[noteIndex].folder);
        const nextFolderIndex = (currentFolderIndex + 1) % foldersOrder.length;
        
        notes[noteIndex].folder = foldersOrder[nextFolderIndex];
        notes[noteIndex].updatedAt = new Date().toISOString();
        
        saveToLocalStorage();
        renderFolders();
        renderNotesList();
    }
    
    // Save notes to localStorage
    function saveToLocalStorage() {
        localStorage.setItem('vishux-notes', JSON.stringify(notes));
    }
    
    // Format text using execCommand
    function formatText(format) {
        switch (format) {
            case 'bold':
                document.execCommand('bold', false, null);
                break;
            case 'italic':
                document.execCommand('italic', false, null);
                break;
            case 'heading':
                document.execCommand('formatBlock', false, '<h2>');
                break;
            case 'unordered-list':
                document.execCommand('insertUnorderedList', false, null);
                break;
            case 'ordered-list':
                document.execCommand('insertOrderedList', false, null);
                break;
            case 'checklist':
                // Simple checklist implementation
                const selection = window.getSelection();
                if (selection.rangeCount > 0) {
                    const range = selection.getRangeAt(0);
                    const li = document.createElement('li');
                    li.style.listStyleType = 'none';
                    li.innerHTML = '<input type="checkbox" style="margin-right: 8px;">' + range.toString();
                    range.deleteContents();
                    range.insertNode(li);
                }
                break;
        }
        
        // Focus back on the content editable
        noteContent.focus();
    }
    
    // Initialize the app
    init();
});